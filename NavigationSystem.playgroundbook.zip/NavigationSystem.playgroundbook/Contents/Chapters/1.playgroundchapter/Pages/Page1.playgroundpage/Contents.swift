/*:
 # Autonomous cars
 
The development of autonomous cars is currently growing.
 
This can be explained by the advantages of using such vehicle, after all about 90% of automobile accidents are caused by human failure!
 
Thus it would be possible to save the lives of millions of people every year, plus the time devoted to driving can be utilized for numerous other purposes.
 
 How about knowing more about how they work?
*/
