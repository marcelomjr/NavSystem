//import Foundation
//
//public func setupCamera(type: CameraType) {
//    
//    navSystem.changeCamera(type: .type)
//}
//
//public func brakeTheCar() {
//    navSystem.brakeTheCar()
//}
//
//public func setSpeedControl(speed: Float) {
//    navSystem.setSpeed(goalSpeed: speed)
//}

